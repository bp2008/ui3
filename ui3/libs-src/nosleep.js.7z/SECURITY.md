# Security Policy

If you find any issues or bugs please report them on the [NoSleep.js Issue Tracker](https://github.com/richtr/NoSleep.js/issues).

If you would like to contribute to this project please consider [forking this repo](https://github.com/richtr/NoSleep.js/fork), making your changes and then creating a new [Pull Request](https://github.com/richtr/NoSleep.js/pulls) back to the main code repository.
