---
name: ✨ Feature Request
about: Suggest an idea for this project

---

<!--
  Issues are so 🔥

  If you remove or skip this template, you'll make the 🐼 sad and the mighty god
  of Github will appear and pile-drive the close button from a great height
  while making animal noises.

  👉🏽 Need support, advice, or help? Don't open an issue!
  Head to StackOverflow https://stackoverflow.com.
-->

* Device Name:
* Device Version:
* Browser Name:
* Browser Version:
* NoSleep.js Version:

### Feature Proposal



### Feature Use Case
